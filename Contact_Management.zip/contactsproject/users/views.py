from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages

from users.models import login_details,contact_d

# Create your views here.
def home(request):
    return render(request, 'users/Login.html')

def login(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')

    details = login_details.objects.filter(email = email,password=password)
    # print(details)
    if details:
        alldetails=contact_d.objects.all()
        emailifmatchcontact=contact_d.objects.filter(User_Email=email).exists()
        # print(emailifmatchcontact,alldetails,email) 
        if emailifmatchcontact:
            records=contact_d.objects.filter(User_Email=email)
        else:
            records=False    
        context={'ifexists':emailifmatchcontact,'login_email':email,'alldetails':alldetails,'records':records}
        # print(details,"loginfunction")
        return render(request, "users/contact.html",context)
    else:
        messages.error(request, "User doesn't exists!!")
        return render(request, 'users/Login.html')

def log(request):
    return render(request, 'users/Login.html')

def signup(request):
    return render(request, "users/signup.html")

def register(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        secret = request.POST.get('secret')

    details = login_details.objects.filter(email = email)
    print(details)
    if details:
        messages.error(request, "Email already exists!!")
        return render(request, "users/signup.html")
    else:    
        details1 = login_details(password=password,email=email,secret=secret)
        details1.save()
        return render(request, 'users/Login.html')

def contact(request):
    if request.method== "POST":
        name = request.POST.get('name')
        email1 = request.POST.get('email1')
        phone_no=request.POST.get('phone_no')
        email2=request.POST.get('email2')

    details=contact_d(User_Email=email2,Name=name,Email=email1,Phone_no=phone_no)
    details.save()
    # alldetails=contact_d.objects.all()
    # emailifmatch=contact_d.objects.get(name=email1)
    if details:
        alldetails=contact_d.objects.all()
        emailifmatchcontact=contact_d.objects.filter(User_Email=email2).exists()
        # print(emailifmatchcontact,alldetails,email) 
        if emailifmatchcontact:
            records=contact_d.objects.filter(User_Email=email2)
        else:
            records=False    
        context={'ifexists':emailifmatchcontact,'login_email':email2,'alldetails':alldetails,'records':records}
        # print(details,"loginfunction")
        return render(request, "users/contact.html",context)
    else:
        messages.error(request, "User doesn't exists!!")
        return render(request, 'users/contact.html')
    # context={'alldetails':alldetails,'login_email':email2}
    # return render(request,"users/contact.html",context)

