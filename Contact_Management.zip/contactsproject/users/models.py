from tabnanny import verbose
from django.db import models

# Create your models here.
class login_details(models.Model):
    email=models.EmailField(max_length=200)
    password=models.CharField(max_length=200)
    secret=models.CharField(max_length=200)
    
class contact_d(models.Model):
    Name=models.CharField(max_length=200)
    Email=models.EmailField(max_length=200)
    Phone_no=models.CharField(max_length=200) 
    User_Email=models.EmailField(max_length=200)